package com.example.android.miwok;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Alex on 1/29/2018.
 */

public class GradeAdapter extends ArrayAdapter<Grade> {
    //Not sure what these does but just add
    private static final String LOG_TAG = GradeAdapter.class.getSimpleName();

    public GradeAdapter(Activity context, ArrayList<Grade> WordListClass) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, WordListClass);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Create variable object listItemView to store all strings
        // make the variable of type View so that ArrayAdapter can properly
        //convert to XML view
        View listItemView = convertView;
        // Check if the existing view is being reused, otherwise inflate the view
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    //call on custom XML layout file created to build views
                    R.layout.layout, parent, false);
        }
        //Once the class has been passed down with the parameters of the word list we set the variable
        //currentWordIndex to that index using these method getItem(position);
        //Data   Variable  get from   getItem() is a built in method
        //Type     name       =      use the current list data in getView method
        Grade currentGradeIndex = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name for default word
        TextView defaultNameTextView = (TextView) listItemView.findViewById(R.id.leftListView);
        // Get the defualt name from the current Word list object and
        // set this text on the name TextView
        defaultNameTextView.setText(currentGradeIndex.getmDeafaultTranslation());

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView miwokNameTextView = (TextView) listItemView.findViewById(R.id.rightListView);
        // Get the miwok name from the current word List object and
        // set this text on the name TextView
        miwokNameTextView.setText(currentGradeIndex.getmMiwokTranslation());

        return listItemView;
    }
}
