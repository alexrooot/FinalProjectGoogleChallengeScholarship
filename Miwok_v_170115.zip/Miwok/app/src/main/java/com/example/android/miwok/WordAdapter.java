package com.example.android.miwok;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * Created by Alex on 1/28/2018.
 */

public class WordAdapter extends ArrayAdapter<Word> {

    private int mColorResourceID;
    //Not sure what these does but just add
    private static final String LOG_TAG = WordAdapter.class.getSimpleName();

    public WordAdapter(Activity context, ArrayList<Word> WordListClass , int colorResourceId) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, WordListClass);
        mColorResourceID = colorResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Create variable object listItemView to store all strings
        // make the variable of type View so that ArrayAdapter can properly
        //convert to XML view
        View listItemView = convertView;
        // Check if the existing view is being reused, otherwise inflate the view
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    //call on custom XML layout file created to build views
                    R.layout.layout, parent, false);
        }
        //Once the class has been passed down with the parameters of the word list we set the variable
        //currentWordIndex to that index using these method getItem(position);
        //Data   Variable  get from   getItem() is a built in method
        //Type     name       =      use the current list data in getView method
        Word currentWordIndex = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name for default word
        TextView defaultNameTextView = (TextView) listItemView.findViewById(R.id.leftListView);
        // Get the defualt name from the current Word list object and
        // set this text on the name TextView
        defaultNameTextView.setText(currentWordIndex.getmDeafaultTranslation());

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView miwokNameTextView = (TextView) listItemView.findViewById(R.id.rightListView);
        // Get the miwok name from the current word List object and
        // set this text on the name TextView
        miwokNameTextView.setText(currentWordIndex.getmMiwokTranslation());

        // Find the Image view in the List_item.xml layout with the ID name so that we now were to put it at
        ImageView iconImageView = (ImageView) listItemView.findViewById(R.id.leftImageView);
        //check what the word class has for method hasImage so that can hide or show ImageaView

        //Find the ImageView in the list_item.xml layout with the id
        ImageView iconPlayID =  (ImageView) listItemView.findViewById(R.id.playImageView);

        iconPlayID.setImageResource(currentWordIndex.getPlayImageResouce());
        if(currentWordIndex.hasImage()){
            //We set the view visible to the creen and add the image
            // now with object created move it to the screen with the following code
            iconImageView.setImageResource(currentWordIndex.getImageResourceId());
        }else {
            //use object and set method for Image view tobe Gone and not shown.
            iconImageView.setVisibility(View.GONE);
        }

        View textColor =  listItemView.findViewById(R.id.text_container);

        int color = ContextCompat.getColor(getContext(),mColorResourceID);

        textColor.setBackgroundColor(color);




        return listItemView;
    }
}
