package com.example.android.miwok;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class PhrasesActivity extends AppCompatActivity {
    private MediaPlayer mMediaPlayer;
    private AudioManager.OnAudioFocusChangeListener mOnAudioFocuseListener;




    //Global MediaPlayer object that listents for when media stops playing
    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        //ArryList list is created using custome class object call word
        //We do this to allow more than one item to be to be group as and
        // object with more than filed
        // final was added to make the arraylist final so that itemonclick works for the sound
        final ArrayList<Word> words = new ArrayList<Word>();
        // method one of creating the object reffrence to the class
        // Floow by adding it to the ArrayList
        Word w = new Word("Where are you going?", "minto wuksus",R.raw.phrase_where_are_you_going, R.drawable.play);
        words.add(w);

        //Option two for is just skip making object name to class
        words.add(new Word("What is your name?", "tinnә oyaase'nә", R.raw.phrase_what_is_your_name, R.drawable.play));
        words.add(new Word("My name is...", "oyaaset...", R.raw.phrase_my_name_is, R.drawable.play));
        words.add(new Word("How are you feeling?", "michәksәs?", R.raw.phrase_how_are_you_feeling, R.drawable.play));
        words.add(new Word("I’m feeling good.", "kuchi achit", R.raw.phrase_im_feeling_good, R.drawable.play));
        words.add(new Word("Are you coming?", "әәnәs'aa?", R.raw.phrase_are_you_coming, R.drawable.play));
        words.add(new Word("Yes, I’m coming.", "hәә’ әәnәm", R.raw.phrase_yes_im_coming, R.drawable.play));
        words.add(new Word("I’m coming.", "әәnәm", R.raw.phrase_im_coming, R.drawable.play));
        words.add(new Word("Let’s go.", "yoowutis", R.raw.phrase_lets_go, R.drawable.play));
        words.add(new Word("Come here.", "әnni'nem", R.raw.phrase_come_here, R.drawable.play));



        //Convert the customize list to a customize ArrayAdapter that can take in more than
        //One item at a time.
        // Create new ArrayAdapter that uses our customize ArrayAdapter
        // So the type will be of the new customize class that we build as WordAdapter
        //Do not pass/tell what data type it is since its customize  !Wrong WordsAdapter<String>!


        //Find the XML style file to a specific view that was custome build to handle ListViews
        ListView listView = (ListView) findViewById(R.id.list);

        WordAdapter Adapter = new WordAdapter(this, words, R.color.category_phrases);

        listView.setAdapter(Adapter);

        //Create a listener Object to be able and call on latter
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //In order to call on right sound you need to listen on cliker
                //to find out what view was click on you need to find out the position
                // creat variable to get view position/index
                //data type
                //  varaible
                //          custom array/list
                //                      built in method to get index of list
                Word word = words.get(position);
                mMediaPlayer = MediaPlayer.create(PhrasesActivity.this, word.getmAudioResource());
                // Start the media now with all the configurations
                mMediaPlayer.start();

                mMediaPlayer.setOnCompletionListener(mCompletionListener);


            }

        });
    }


    // overide/ call on method onStop to stop and release resources
    //Automaticly is liseneting
    @Override
    protected void onStop() {
        super.onStop();
        //Call on the release mediaplaer method that will check if there is a media playing and
        // if it is it will release it
        releaseMediaPlayer();
    }


    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mMediaPlayer != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mMediaPlayer.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mMediaPlayer = null;


        }


        /**
         * Find the root view of the XML layout file, Then can add textview or other views
         */

        /**
         *

         for (int index =0; index < words.size(); index++){
         LinearLayout rootView = (LinearLayout) findViewById(R.id.rootView);
         TextView wordView = new TextView(this);
         wordView.setText((String)words.get(index));
         rootView.addView(wordView);
         rootView.setPadding(16, 16, 0,0);
         }
         */

    }
}
