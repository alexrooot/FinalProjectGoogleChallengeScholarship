package com.example.android.miwok;

/**
 * Created by Alex on 1/29/2018.
 */

public class Grade {

    ///Default translation for the word m=member


    //Miwok translation for the word m=member
    private String percent;
    private String letter;

    /**
     * The class must be paased two variables
     * @param letterGrade
     * @param percentgrade
     */
    public Grade(String percentgrade, String letterGrade){
        letter = letterGrade;
        percent = percentgrade;
    }
    //get the default translation of the word
    public String getmDeafaultTranslation(){
        return letter;
    }
    //Get the Miwok translation
    public String getmMiwokTranslation(){
        return percent;
    }

}