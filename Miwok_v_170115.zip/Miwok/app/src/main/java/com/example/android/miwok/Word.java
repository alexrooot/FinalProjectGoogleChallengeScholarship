package com.example.android.miwok;

import java.security.PrivateKey;

/**
 * Created by Alex on 1/28/2018.
 */

public class Word {

    //Default translation for the word m=member
    private String mDeafaultTranslation;

    //Miwok translation for the word m=member
    private String mMiwokTranslation;

    //Set private intiger for image id to later have it build to the ImageView
    //private int mImageResource ;

    //These version of image id varible is going to be set to be hiden at first
    // if nothing is passed onto class
    private int mImageResource = NO_IMAGE_PROVIDED;
    //These priavte varible was just used in order to set Image varible to hiden
    private static final int NO_IMAGE_PROVIDED = -1;

    private int mAudioResource;

    private int mImagePlayResource;

    /**
     * The class must be paased two variables
     * @param DeafaultTranslation
     * @param MiwokTranslation
     * @param audioResource
     */
    public Word(String DeafaultTranslation, String MiwokTranslation, int audioResource, int playImage){
        mDeafaultTranslation = DeafaultTranslation;
        mMiwokTranslation = MiwokTranslation;
        mAudioResource = audioResource;
        mImagePlayResource = playImage;

    }



    /**
     *
     * @param DeafaultTranslation
     * @param MiwokTranslation
     * @param image
     * @param audioResource
     */
    public Word(String DeafaultTranslation, String MiwokTranslation, int image, int audioResource, int playImage){
        mDeafaultTranslation = DeafaultTranslation;
        mMiwokTranslation = MiwokTranslation;
        mImageResource = image;
        mAudioResource = audioResource;
        mImagePlayResource = playImage;

    }
    //get the default translation of the word
    public String getmDeafaultTranslation(){
        return mDeafaultTranslation;
    }
    //Get the Miwok translation
    public String getmMiwokTranslation(){
        return mMiwokTranslation;
    }
    public int getImageResourceId(){
        return mImageResource;
    }
    //Check to see if we have image
    // we retun a true or false field to the WordAdapter so that we can use and if statement
    // That way we can hise the Imageview from apearing in screen
    public boolean hasImage(){
        return mImageResource != NO_IMAGE_PROVIDED;

    }
    public  int getmAudioResource(){
        return mAudioResource;
    }

    public  int getPlayImageResouce(){
        return  mImagePlayResource;
    }
    //Print to a log debuger android studio
    //Right clcik
    //clcik Generate
    //click toString()
    @Override
    public String toString() {
        return "Word{" +
                "mDeafaultTranslation='" + mDeafaultTranslation + '\'' +
                ", mMiwokTranslation='" + mMiwokTranslation + '\'' +
                ", mImageResource=" + mImageResource +
                ", mAudioResource=" + mAudioResource +
                '}';
    }
}
