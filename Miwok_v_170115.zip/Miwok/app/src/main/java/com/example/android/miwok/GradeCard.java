package com.example.android.miwok;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by Alex on 1/29/2018.
 */

public class GradeCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Grade> grade = new ArrayList<Grade>();
        grade.add(new Grade("80.10","B-"));
        grade.add(new Grade("92.44","A-"));
        grade.add(new Grade("91.10","A-"));
        grade.add(new Grade("74.20","C"));
        grade.add(new Grade("70.71","C-"));
        grade.add(new Grade("90.11","A-"));




        GradeAdapter Adapter = new GradeAdapter(this, grade);
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(Adapter);
    }









}

