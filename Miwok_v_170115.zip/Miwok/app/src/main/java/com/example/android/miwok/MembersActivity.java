package com.example.android.miwok;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MembersActivity extends AppCompatActivity {
    private MediaPlayer mMediaPlayer;

    //Global MediaPlayer object that listents for when media stops playing
    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.word_list);

        //ArryList list is created using custome class object call word
        //We do this to allow more than one item to be to be group as and
        // object with more than filed
        // final was added to make the arraylist final so that itemonclick works for the sound
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("father", "әpә", R.drawable.family_father, R.raw.family_father, R.drawable.play));
        words.add(new Word("mother", "әṭa", R.drawable.family_mother, R.raw.family_mother, R.drawable.play));
        words.add(new Word("son", "angsi", R.drawable.family_son, R.raw.family_son, R.drawable.play));
        words.add(new Word("daughter", "tune", R.drawable.family_daughter, R.raw.family_daughter, R.drawable.play));
        words.add(new Word("older brother", "taachi", R.drawable.family_older_brother, R.raw.family_older_brother, R.drawable.play));
        words.add(new Word("younger brother", "chalitti", R.drawable.family_younger_brother, R.raw.family_younger_brother, R.drawable.play));
        words.add(new Word("older sister", "teṭe", R.drawable.family_older_sister, R.raw.family_older_sister, R.drawable.play));
        words.add(new Word("younger sister", "kolliti", R.drawable.family_younger_sister, R.raw.family_younger_sister, R.drawable.play));
        words.add(new Word("grandmother ", "ama", R.drawable.family_grandmother, R.raw.family_grandmother, R.drawable.play));
        words.add(new Word("grandfather", "paapa", R.drawable.family_grandfather, R.raw.family_grandfather, R.drawable.play));

        //Convert the customize list to a customize ArrayAdapter that can take in more than
        //One item at a time.
        // Create new ArrayAdapter that uses our customize ArrayAdapter
        // So the type will be of the new customize class that we build as WordAdapter
        //Do not pass/tell what data type it is since its customize  !Wrong WordsAdapter<String>!
        WordAdapter Adapter = new WordAdapter(this, words, R.color.category_family);

        //Find the XML style file to a specific view that was custome build to handle ListViews
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(Adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Word word = words.get(position);

                mMediaPlayer = MediaPlayer.create(MembersActivity.this, word.getmAudioResource());
                // Start the media now with all the configurations
                mMediaPlayer.start();

                mMediaPlayer.setOnCompletionListener(mCompletionListener);


            }

        });}

        // overide/ call on method onStop to stop and release resources
        //Automaticly is liseneting
        @Override
        protected void onStop() {
        super.onStop();
        //Call on the releasemediaplaer method that will check if there is a media playing and
        // if it is it will release it
        releaseMediaPlayer();
        }


    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mMediaPlayer != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mMediaPlayer.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mMediaPlayer = null;


        }
    }


    /**
     * Find the root view of the XML layout file, Then can add textview or other views
     */

    /**
     *

     for (int index =0; index < words.size(); index++){
     LinearLayout rootView = (LinearLayout) findViewById(R.id.rootView);
     TextView wordView = new TextView(this);
     wordView.setText((String)words.get(index));
     rootView.addView(wordView);
     rootView.setPadding(16, 16, 0,0);
     }
     */


}

