package com.example.android.miwok;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ColorActivity extends AppCompatActivity {
    private MediaPlayer mMediaPlayer;

    //Global MediaPlayer object that listents for when media stops playing
    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releaseMediaPlayer();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        setContentView(R.layout.word_list);

        //ArryList list is created using custome class object call word
        //We do this to allow more than one item to be to be group as and
        // object with more than filed
        // final was added to make the arraylist final so that itemonclick works for the sound
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("red", "weṭeṭṭi",R.drawable.color_red, R.raw.color_red, R.drawable.play));
        words.add(new Word("mustard yellow", "chiwiiṭә", R.drawable.color_mustard_yellow, R.raw.color_mustard_yellow, R.drawable.play));
        words.add(new Word("dusty yellow", "ṭopiisә", R.drawable.color_dusty_yellow, R.raw.color_dusty_yellow, R.drawable.play));
        words.add(new Word("green", "chokokki", R.drawable.color_green, R.raw.color_green, R.drawable.play));
        words.add(new Word("brown", "ṭakaakki",R.drawable.color_brown, R.raw.color_brown, R.drawable.play));
        words.add(new Word("gray", "ṭopoppi",R.drawable.color_gray, R.raw.color_gray, R.drawable.play));
        words.add(new Word("black", "kululli",R.drawable.color_black, R.raw.color_black, R.drawable.play));
        words.add(new Word("white", "kelelli",R.drawable.color_white, R.raw.color_white, R.drawable.play));


        //Convert the customize list to a customize ArrayAdapter that can take in more than
        //One item at a time.
        // Create new ArrayAdapter that uses our customize ArrayAdapter
        // So the type will be of the new customize class that we build as WordAdapter
        //Do not pass/tell what data type it is since its customize  !Wrong WordsAdapter<String>!
        WordAdapter adapter = new WordAdapter(this, words, R.color.category_colors);


        //Find the XML style file to a specific view that was custome build to handle ListViews
        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Word word = words.get(position);
                mMediaPlayer = MediaPlayer.create(ColorActivity.this, word.getmAudioResource());
                // Start the media now with all the configurations
                mMediaPlayer.start();

                mMediaPlayer.setOnCompletionListener(mCompletionListener);


            }

        });
    }


    // overide/ call on method onStop to stop and release resources
    //Automaticly is liseneting
    @Override
    protected void onStop() {
        super.onStop();
        //Call on the releasemediaplaer method that will check if there is a media playing and
        // if it is it will release it
        releaseMediaPlayer();
    }

    private void releaseMediaPlayer() {
        // If the media player is not null, then it may be currently playing a sound.
        if (mMediaPlayer != null) {
            // Regardless of the current state of the media player, release its resources
            // because we no longer need it.
            mMediaPlayer.release();

            // Set the media player back to null. For our code, we've decided that
            // setting the media player to null is an easy way to tell that the media player
            // is not configured to play an audio file at the moment.
            mMediaPlayer = null;


        }


        /**
         * Find the root view of the XML layout file, Then can add textview or other views
         */

        /**
         *

         for (int index =0; index < words.size(); index++){
         LinearLayout rootView = (LinearLayout) findViewById(R.id.rootView);
         TextView wordView = new TextView(this);
         wordView.setText((String)words.get(index));
         rootView.addView(wordView);
         rootView.setPadding(16, 16, 0,0);
         }
         */

    }
}
